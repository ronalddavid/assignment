	
	$( document ).ready(function() {
		$(".releaseyearblg").css("display", "none");		
		$(".releaseyearblg1").css("padding", "0px");
	});

	// Get related Movies
	
	function getrelatedmovies() {
		$(".releaseyearblg1").css("padding", "0px");
		$("#moviedetails").show();		
		$("#backbtn").hide();
		$("#releaseyearmovies").hide();		
		$("#detailssblg").hide();		
		var key ="";
		key = $("#moviename").val();
		
		if(key == "")
		{			
			$(".searchresult").hide();
		}
		{
			$(".searchresult").show();
		}
		
		var url ="https://api.themoviedb.org/3/search/movie?api_key=8c4d33270b86d433f0e3f8e6332a8fb1&language=en-US&query="+key+"&page=1";
		var settings = {
			"async": true,
			"crossDomain": true, 
			"url": url,
			"method": "GET",
			"headers": {},
			"data": "{}"
		}
		
		$.ajax(settings).done(function (response) {
		$("#moviedetails tbody > tr").remove();			
			var data = response;				
			var count = 0;
			for (var i=0; i<data.results.length; i++) {
				if(count < 10)
				{
				var	movieid = data.results[i].id;
				var getimgurl = "https://image.tmdb.org/t/p/w300_and_h450_bestv2"+data.results[i].poster_path;
				if(data.results[i].poster_path == null)
				{
					getimgurl = "img/movie.png";
				}
				else				
				{
					getimgurl = getimgurl;
				}
				var releasedate= data.results[i].release_date;		
				var releaseyear = releasedate.substring(0,4);		
				var row = $('<tr><td ><img class="img-responsive " src='+ getimgurl + '></td><td >' + data.results[i].release_date+ '</td><td><a onclick=releaseyear("'+ data.results[i].id+","+ releaseyear + '")>' + data.results[i].title + '</a></td></tr>');
				$('#moviedetails').append(row);
				}
				else
				{
					break;
				}
				count = count +1;
			}
		});			
	}
			
	//Go Back
	
	function goback()
	{
		$(".releaseyearblg1").css("padding", "0px");
		$(".searchresult").css("display", "block");
		$(".releaseyearblg").css("display", "none");
		$("#moviedetails").show();
		$("#backbtn").hide();
		$("#releaseyearmovies").hide();		
		$("#detailssblg").hide();		
	}
	
	//Get the Movies of the silimar year
	
	function releaseyear(idyear)
	{
		$(".releaseyearblg1").css("padding", "30px");
		$(".searchresult").css("display", "none");
		$(".releaseyearblg").css("display", "block");		
		$("#detailssblg").show();
		$("#moviedetails").hide();
		$("#backbtn").show();
		$("#releaseyearmovies").show();
		$("#releaseyearmovies tbody > tr").remove();
		var idyear = idyear.split(',');
		var flimid = idyear[0]; 
		var yearofrelease = idyear[1];
		var url ="https://api.themoviedb.org/3/discover/movie?api_key=8c4d33270b86d433f0e3f8e6332a8fb1&language=en-US&primary_release_year="+yearofrelease;
		var settings = {
			"async": true,
			"crossDomain": true, 
			"url": url,
			"method": "GET",
			"headers": {},
			"data": "{}"
		}
		
		$.ajax(settings).done(function (response) {
			var data = response;				
			var count1 = 0;
			for (var i=0; i<data.results.length; i++) {	
				if(count1 < 10)
				{
					var	movieid = data.results[i].id;
					var getimgurl = "https://image.tmdb.org/t/p/w300_and_h450_bestv2"+data.results[i].poster_path;
					if(data.results[i].poster_path == null)
					{
						getimgurl = "img/movie.png";
					}
					else				
					{
						getimgurl = getimgurl;
					}
					var releasedate= data.results[i].release_date;		
					var releaseyear = releasedate.substring(0,4);		
					var row = $('<tr><td><img class="img-responsive " src='+ getimgurl + '></td><td >' + data.results[i].release_date+ '</td><td>' + data.results[i].title + '</td></tr>');
					$('#releaseyearmovies').append(row);
				}
				else
				{
					break;
				}
				count1 = count1 +1;
			}
		});		
		
		var detailsurl ="https://api.themoviedb.org/3/movie/"+flimid+"?api_key=8c4d33270b86d433f0e3f8e6332a8fb1&language=en-US";
		var detailssettings = {
			"async": true,
			"crossDomain": true, 
			"url": detailsurl,
			"method": "GET",
			"headers": {},
			"data": "{}"
		}
		
		$.ajax(detailssettings).done(function (response) {			
			var data = response;	
			$('.movieimgblog').empty();$('.moviedetails').empty();			
			var getimgurl = "https://image.tmdb.org/t/p/w300_and_h450_bestv2"+data.poster_path;
				if(data.poster_path == null)
				{
					getimgurl = "img/movie.png";
				}
				else{
					getimgurl = getimgurl;	
				}
				var imga = $('<img style="width: 100%; margin: auto;" class="img-responsive " src='+ getimgurl + '>');
				$('.movieimgblog').append(imga);
				var moviedetails = $('<h4>'+data.title+'</h4><p>'+ data.overview+'</p><p>'+data.release_date+'</p><p>'+data.homepage+'</p>');
				$('.moviedetails').append(moviedetails);
		});
	}